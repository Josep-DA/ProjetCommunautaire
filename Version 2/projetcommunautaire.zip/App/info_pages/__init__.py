# Import the Blueprint
from .blueprint_setup import info

# Import the urls / pages
from .endpoints import root, secure, home
