# Import the Blueprint
from .blueprint_setup import post

# Import the urls / pages
from .endpoints import root, secure, home