# This file and all the others are dictated to our community project of myp 4.

# -------------------------------------------------------------------------- #

class Config:
    SECRET_KEY = '8w$E)0plK6#F2!CCr%MpVv8j6j)*eCJq6yx(R)qSN4XfK$'
