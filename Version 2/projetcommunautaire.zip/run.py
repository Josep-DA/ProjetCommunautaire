# This file and all the others are dictated to our community project of myp 4.

# -------------------------------------------------------------------------- #
# Imports
from App import run_app

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    run_app()
